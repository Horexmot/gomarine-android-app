# 🚢 GoMarine Android App

A modern Android WebView application for GoMarine.gr - your nautical equipment e-commerce store.

---

## ✨ Features

- 🌐 **Full WebView Integration** - Loads www.gomarine.gr seamlessly
- 📱 **Native Android Experience** - Splash screen, smooth navigation
- 🔄 **Pull to Refresh** - Swipe down to reload the page
- 📥 **File Downloads** - Download PDFs, images, and other files
- 📤 **File Uploads** - Upload files through web forms
- 📞 **External Links** - Phone, email, WhatsApp links open in native apps
- 🌐 **External Websites** - Opens external sites in browser
- 🔒 **SSL Security** - Handles SSL certificate issues gracefully
- 📶 **Offline Detection** - Shows dialog when no internet
- ⬅️ **Back Navigation** - Smart back button handling
- 🎨 **Custom Theme** - Matches GoMarine brand colors

---

## 📋 Requirements

- **Android Studio**: Hedgehog (2023.1.1) or newer
- **Android SDK**: API 24+ (Android 7.0+)
- **Target SDK**: API 34 (Android 14)
- **Kotlin**: 1.9.20+
- **Gradle**: 8.2+

---

## 🚀 Quick Start

### 1. Open Project in Android Studio

```bash
# Open the gomarine-android-app folder in Android Studio
File → Open → Select "gomarine-android-app" folder
```

### 2. Sync Project

```bash
# Click "Sync Now" in the notification bar
# Or: File → Sync Project with Gradle Files
```

### 3. Build APK

```bash
# Build → Build Bundle(s) / APK(s) → Build APK(s)
# Or use Gradle: ./gradlew assembleDebug
```

### 4. Run on Device

```bash
# Connect Android device or start emulator
# Run → Run 'app'
```

---

## 📦 Build Release APK

### Step 1: Generate Keystore

```bash
keytool -genkey -v -keystore gomarine.keystore -alias gomarine -keyalg RSA -keysize 2048 -validity 10000
```

### Step 2: Configure Signing

Create `app/keystore.properties`:

```properties
storeFile=../gomarine.keystore
storePassword=your_password
keyAlias=gomarine
keyPassword=your_password
```

### Step 3: Build Release

```bash
# In Android Studio:
Build → Generate Signed Bundle / APK

# Or via command line:
./gradlew assembleRelease
```

The APK will be at:
```
app/build/outputs/apk/release/app-release.apk
```

---

## 🎨 Customization

### Change Website URL

Edit `MainActivity.kt`:

```kotlin
companion object {
    private const val WEBSITE_URL = "https://www.gomarine.gr"
    // Change to your URL
}
```

### Change App Name

Edit `app/src/main/res/values/strings.xml`:

```xml
<string name="app_name">Your App Name</string>
```

### Change Colors

Edit `app/src/main/res/values/colors.xml`:

```xml
<color name="primary_color">#1A5276</color>
<color name="accent_color">#F39C12</color>
```

### Change Icons

Replace files in:
- `app/src/main/res/mipmap-hdpi/`
- `app/src/main/res/mipmap-mdpi/`
- `app/src/main/res/mipmap-xhdpi/`
- `app/src/main/res/mipmap-xxhdpi/`
- `app/src/main/res/mipmap-xxxhdpi/`

Use Android Studio's **Image Asset Studio**:
```
Right-click res → New → Image Asset
```

---

## 📁 Project Structure

```
gomarine-android-app/
├── app/
│   ├── src/main/
│   │   ├── java/com/gomarine/app/
│   │   │   └── MainActivity.kt      # Main Activity with WebView
│   │   ├── res/
│   │   │   ├── drawable/
│   │   │   │   ├── ic_splash.xml    # Splash screen icon
│   │   │   │   └── progress_drawable.xml
│   │   │   ├── layout/
│   │   │   │   └── activity_main.xml # Main layout
│   │   │   ├── mipmap-*/            # App icons
│   │   │   ├── values/
│   │   │   │   ├── colors.xml       # Color definitions
│   │   │   │   ├── strings.xml      # String resources
│   │   │   │   └── themes.xml       # App themes
│   │   │   └── xml/
│   │   │       ├── backup_rules.xml
│   │   │       └── data_extraction_rules.xml
│   │   └── AndroidManifest.xml      # App manifest
│   ├── build.gradle                 # App-level build config
│   └── proguard-rules.pro           # ProGuard rules
├── build.gradle                     # Project-level build config
├── settings.gradle                  # Project settings
├── gradle.properties                # Gradle properties
└── README.md                        # This file
```

---

## 🔧 Configuration

### AndroidManifest.xml Permissions

```xml
<uses-permission android:name="android.permission.INTERNET" />
<uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
<uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" />
```

### WebView Settings

The WebView is configured with:
- ✅ JavaScript enabled
- ✅ DOM storage enabled
- ✅ Database enabled
- ✅ Cache enabled
- ✅ Zoom controls
- ✅ File upload/download support
- ✅ Cookie management

---

## 📱 App Behavior

### Navigation
- **Back Button**: Goes back in WebView history, shows exit dialog on homepage
- **Swipe Down**: Refreshes the current page
- **External Links**: Opens phone, email, WhatsApp in native apps
- **External Websites**: Opens in browser (not in app)

### Downloads
- Files download to device's Downloads folder
- Shows notification when download completes

### Uploads
- Supports file upload through web forms
- Opens file picker when clicking upload button

### Offline Mode
- Shows dialog when no internet connection
- Option to retry or exit

---

## 🐛 Troubleshooting

### Build Errors

**Error: Gradle sync failed**
```bash
# Solution: Update Android Studio and Gradle
File → Invalidate Caches / Restart
```

**Error: Minimum SDK version**
```bash
# Solution: Update minSdk in app/build.gradle
minSdk 24  # or higher
```

### Runtime Issues

**Website not loading**
- Check internet permission in AndroidManifest.xml
- Verify WEBSITE_URL is correct
- Check if website uses HTTPS

**SSL Certificate Error**
- App shows dialog to proceed or cancel
- For production, ensure website has valid SSL certificate

**File download not working**
- Check WRITE_EXTERNAL_STORAGE permission
- Verify DownloadManager is available

---

## 📤 Publishing to Google Play

### 1. Create Google Play Developer Account
- Visit: https://play.google.com/console
- Pay one-time $25 fee

### 2. Prepare Store Listing
- App name: GoMarine
- Short description: Ναυτιλιακά είδη και εξοπλισμός σκαφών
- Full description: Detailed app description
- Screenshots: Phone and tablet screenshots
- Feature graphic: 1024x500px
- App icon: 512x512px

### 3. Generate Signed AAB
```bash
Build → Generate Signed Bundle → Android App Bundle
```

### 4. Upload to Play Console
- Create new app
- Upload AAB file
- Fill store listing
- Set pricing (Free)
- Select countries
- Publish

---

## 📄 License

This app is created for GoMarine.gr and can be freely modified.

---

## 📞 Support

For issues or questions:
1. Check Android Studio logs (Logcat)
2. Verify website URL is accessible
3. Test on different Android versions
4. Check for JavaScript errors in WebView

---

**GoMarine Android App v1.0.0**
Built with ❤️ for www.gomarine.gr
