package com.gomarine.app

import android.annotation.SuppressLint
import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.net.http.SslError
import android.os.Bundle
import android.os.Environment
import android.view.KeyEvent
import android.view.View
import android.webkit.CookieManager
import android.webkit.DownloadListener
import android.webkit.SslErrorHandler
import android.webkit.URLUtil
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.ProgressBar
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.google.android.material.snackbar.Snackbar

class MainActivity : AppCompatActivity() {

    companion object {
        private const val WEBSITE_URL = "https://www.gomarine.gr"
        private const val REQUEST_FILE_CHOOSER = 1
    }

    private lateinit var webView: WebView
    private lateinit var progressBar: ProgressBar
    private lateinit var swipeRefreshLayout: SwipeRefreshLayout
    private var filePathCallback: ValueCallback<Array<Uri>>? = null
    private var isPageLoaded = false

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        // Install splash screen
        val splashScreen = installSplashScreen()
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Initialize views
        webView = findViewById(R.id.webView)
        progressBar = findViewById(R.id.progressBar)
        swipeRefreshLayout = findViewById(R.id.swipeRefreshLayout)

        // Setup WebView
        setupWebView()

        // Setup SwipeRefresh
        setupSwipeRefresh()

        // Setup back button handling
        setupBackButton()

        // Load website
        if (savedInstanceState == null) {
            loadWebsite()
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        webView.apply {
            settings.apply {
                // Enable JavaScript
                javaScriptEnabled = true
                
                // Enable DOM storage
                domStorageEnabled = true
                
                // Enable database storage
                databaseEnabled = true
                
                // Enable AppCache (deprecated but still needed for some sites)
                @Suppress("DEPRECATION")
                setAppCacheEnabled(true)
                @Suppress("DEPRECATION")
                setAppCachePath(context.cacheDir.absolutePath)
                
                // Enable caching
                cacheMode = WebSettings.LOAD_DEFAULT
                
                // Enable zoom controls
                setSupportZoom(true)
                builtInZoomControls = true
                displayZoomControls = false
                
                // Enable media playback
                mediaPlaybackRequiresUserGesture = false
                
                // Mixed content mode (allow HTTPS page to load HTTP content)
                mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
                
                // User agent
                userAgentString = "$userAgentString GoMarineApp/1.0"
                
                // Enable wide viewport
                useWideViewPort = true
                loadWithOverviewMode = true
                
                // Enable JavaScript can open windows automatically
                javaScriptCanOpenWindowsAutomatically = true
                
                // Set text zoom
                textZoom = 100
            }

            // Enable cookies
            CookieManager.getInstance().apply {
                setAcceptCookie(true)
                setAcceptThirdPartyCookies(webView, true)
            }

            // WebView Client
            webViewClient = object : WebViewClient() {
                override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                    super.onPageStarted(view, url, favicon)
                    progressBar.visibility = View.VISIBLE
                    isPageLoaded = false
                }

                override fun onPageFinished(view: WebView?, url: String?) {
                    super.onPageFinished(view, url)
                    progressBar.visibility = View.GONE
                    swipeRefreshLayout.isRefreshing = false
                    isPageLoaded = true
                }

                override fun shouldOverrideUrlLoading(
                    view: WebView?,
                    request: WebResourceRequest?
                ): Boolean {
                    val url = request?.url?.toString() ?: return false
                    
                    // Handle external URLs
                    return when {
                        url.startsWith("tel:") -> {
                            startActivity(Intent(Intent.ACTION_DIAL, Uri.parse(url)))
                            true
                        }
                        url.startsWith("mailto:") -> {
                            startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse(url)))
                            true
                        }
                        url.startsWith("whatsapp:") -> {
                            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                            true
                        }
                        url.startsWith("http://") || url.startsWith("https://") -> {
                            // Check if it's an external site
                            if (!url.contains("gomarine.gr")) {
                                // Open external links in browser
                                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                                true
                            } else {
                                false // Load in WebView
                            }
                        }
                        else -> false
                    }
                }

                override fun onReceivedError(
                    view: WebView?,
                    request: WebResourceRequest?,
                    error: WebResourceError?
                ) {
                    super.onReceivedError(view, request, error)
                    if (request?.isForMainFrame == true) {
                        showErrorSnackbar("Σφάλμα φόρτωσης σελίδας")
                    }
                }

                @SuppressLint("WebViewClientOnReceivedSslError")
                override fun onReceivedSslError(
                    view: WebView?,
                    handler: SslErrorHandler?,
                    error: SslError?
                ) {
                    // Show SSL error dialog
                    AlertDialog.Builder(this@MainActivity)
                        .setTitle("Προειδοποίηση Ασφαλείας")
                        .setMessage("Υπάρχει πρόβλημα με το πιστοποιητικό ασφαλείας. Θέλετε να συνεχίσετε;")
                        .setPositiveButton("Συνέχεια") { _, _ -> handler?.proceed() }
                        .setNegativeButton("Ακύρωση") { _, _ -> handler?.cancel() }
                        .show()
                }
            }

            // Web Chrome Client (for progress and file upload)
            webChromeClient = object : WebChromeClient() {
                override fun onProgressChanged(view: WebView?, newProgress: Int) {
                    super.onProgressChanged(view, newProgress)
                    progressBar.progress = newProgress
                }

                override fun onShowFileChooser(
                    webView: WebView?,
                    filePathCallback: ValueCallback<Array<Uri>>?,
                    fileChooserParams: FileChooserParams?
                ): Boolean {
                    this@MainActivity.filePathCallback?.onReceiveValue(null)
                    this@MainActivity.filePathCallback = filePathCallback

                    val intent = fileChooserParams?.createIntent()
                    try {
                        startActivityForResult(intent, REQUEST_FILE_CHOOSER)
                    } catch (e: Exception) {
                        this@MainActivity.filePathCallback = null
                        return false
                    }
                    return true
                }
            }

            // Download listener
            setDownloadListener { url, userAgent, contentDisposition, mimeType, contentLength ->
                handleDownload(url, userAgent, contentDisposition, mimeType)
            }
        }
    }

    private fun setupSwipeRefresh() {
        swipeRefreshLayout.apply {
            setColorSchemeColors(
                ContextCompat.getColor(this@MainActivity, R.color.primary_color),
                ContextCompat.getColor(this@MainActivity, R.color.accent_color)
            )
            setOnRefreshListener {
                webView.reload()
            }
        }
    }

    private fun setupBackButton() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (webView.canGoBack()) {
                    webView.goBack()
                } else {
                    // Show exit confirmation
                    AlertDialog.Builder(this@MainActivity)
                        .setTitle("Έξοδος")
                        .setMessage("Θέλετε να κλείσετε την εφαρμογή;")
                        .setPositiveButton("Ναι") { _, _ -> finish() }
                        .setNegativeButton("Όχι", null)
                        .show()
                }
            }
        })
    }

    private fun loadWebsite() {
        if (isNetworkAvailable()) {
            webView.loadUrl(WEBSITE_URL)
        } else {
            showNoInternetDialog()
        }
    }

    private fun handleDownload(
        url: String,
        userAgent: String,
        contentDisposition: String,
        mimeType: String
    ) {
        val request = DownloadManager.Request(Uri.parse(url)).apply {
            setMimeType(mimeType)
            addRequestHeader("User-Agent", userAgent)
            setDescription("Λήψη αρχείου...")
            setTitle(URLUtil.guessFileName(url, contentDisposition, mimeType))
            allowScanningByMediaScanner()
            setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, URLUtil.guessFileName(url, contentDisposition, mimeType))
        }

        val downloadManager = getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        downloadManager.enqueue(request)

        Toast.makeText(this, "Η λήψη ξεκίνησε...", Toast.LENGTH_SHORT).show()
    }

    private fun isNetworkAvailable(): Boolean {
        val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as android.net.ConnectivityManager
        val networkInfo = connectivityManager.activeNetworkInfo
        return networkInfo != null && networkInfo.isConnected
    }

    private fun showNoInternetDialog() {
        AlertDialog.Builder(this)
            .setTitle("Χωρίς Σύνδεση")
            .setMessage("Δεν υπάρχει σύνδεση στο διαδίκτυο. Ελέγξτε τις ρυθμίσεις δικτύου σας.")
            .setPositiveButton("Επανάληψη") { _, _ -> loadWebsite() }
            .setNegativeButton("Έξοδος") { _, _ -> finish() }
            .setCancelable(false)
            .show()
    }

    private fun showErrorSnackbar(message: String) {
        Snackbar.make(webView, message, Snackbar.LENGTH_LONG)
            .setAction("Επανάληψη") { webView.reload() }
            .show()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        
        if (requestCode == REQUEST_FILE_CHOOSER) {
            filePathCallback?.let {
                val results = if (resultCode == RESULT_OK && data != null) {
                    WebChromeClient.FileChooserParams.parseResult(resultCode, data)
                } else null
                it.onReceiveValue(results)
                filePathCallback = null
            }
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        webView.saveState(outState)
    }

    override fun onRestoreInstanceState(savedInstanceState: Bundle) {
        super.onRestoreInstanceState(savedInstanceState)
        webView.restoreState(savedInstanceState)
    }

    override fun onResume() {
        super.onResume()
        webView.onResume()
    }

    override fun onPause() {
        super.onPause()
        webView.onPause()
    }

    override fun onDestroy() {
        webView.destroy()
        super.onDestroy()
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_BACK && webView.canGoBack()) {
            webView.goBack()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }
}
